# Twitter Tab Switcher Extension

## Installation Instructions

- Clone this repo
- Open Chrome/Edge
- Enable Developer Mode
- Load the root directory as an Unpacked Extension

## Usage

Load Twitter and give it about 2 seconds.
